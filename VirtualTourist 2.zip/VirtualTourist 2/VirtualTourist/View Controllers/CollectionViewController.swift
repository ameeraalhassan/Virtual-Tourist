//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Ameera AlHassan on 8/20/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController, NSFetchedResultsControllerDelegate, UICollectionViewDelegate, UICollectionViewDataSource {
    
    let imageCell = "ImageCell"
    
    @IBOutlet weak var flow: UICollectionViewFlowLayout!
    var pin: MapViewPin!
    
    var dataController: DataController!
    var fetchedResultsController: NSFetchedResultsController<CollectionView>!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        let space: CGFloat = 3.0
               let dimension = (self.view.frame.size.width - (2 * space)) / 3.0
               flow.minimumInteritemSpacing = space
               flow.minimumLineSpacing = space
               flow.itemSize = CGSize(width: dimension, height: dimension)
        
        super.viewDidLoad()
        setUpUI()
        
        guard let newPin = pin else { return }
        
        setUpFetchedResultsController(newPin)
        
        if fetchedResultsController.fetchedObjects!.count == 0 {
            loadImages(pin: newPin, page: 1)
        }
    }
    
    fileprivate func setUpUI() {
        // fetchedResultsController.delegate = self
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        fetchedResultsController = nil
    }
    
    fileprivate func setUpFetchedResultsController(_ newPin: MapViewPin) {
        
        let fetchRequest:NSFetchRequest<CollectionView> = CollectionView.fetchRequest()
        let predicate = NSPredicate(format: "pin == %@", pin)
        fetchRequest.predicate = predicate
        fetchRequest.sortDescriptors = []
        
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: self.dataController.viewContext, sectionNameKeyPath: nil, cacheName: nil)
        
        fetchedResultsController.delegate = self
        do {
            try fetchedResultsController.performFetch()
        } catch {
            fatalError("The fetch could not be performed: \(error.localizedDescription)")
        }
}

    @IBAction func newCollectionTapped(_ sender: Any) {
        for photo in fetchedResultsController.fetchedObjects! {
            dataController.viewContext.delete(photo)
        }
        let randomNum = Int.random(in: 2...10)
        loadImages(pin: pin, page: randomNum)
        setUpFetchedResultsController(pin)
    }
    
    func imageDeletion(_ sender: Any){
        for image in fetchedResultsController.fetchedObjects! {
            dataController.viewContext.delete(image)
        }
    }
    
    func loadImages(pin: MapViewPin, page: Int) {
        
        let flickrObject = FlickrAPI.flickrObject
        
        flickrObject.fetchImagesForLocation(latitude: pin.latitude, longitude: pin.longitude, page: page) { (flickrImages: [ImageDetails]?, error: Error?) in
            
            guard flickrImages!.count != 0 else {
                let alert = UIAlertController(title: "No Images", message: "Sorry, no images for this location", preferredStyle: .alert)
                let action = UIAlertAction(title: "ok", style: .default, handler: nil)
                alert.addAction(action)
                self.present(alert, animated: true, completion: nil)
                
                return }
            
            if let flickrImages = flickrImages {
                for image in flickrImages {
                    if let id = image.id,
                        let secret = image.secret,
                        let server = image.server,
                        let farm = image.farm {
                        let url = "https://farm\(farm).staticflickr.com/\(server)/\(id)_\(secret).jpg"
                        let image = CollectionView(context: self.dataController.viewContext)
                        image.imageURL = url
                        image.pin = self.pin
                    }
                    do {
                        try self.dataController.viewContext.save()
                        DispatchQueue.main.async {
                            self.collectionView.reloadData()
                        }
                    } catch  {
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fetchedResultsController.sections?[section].numberOfObjects ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: imageCell, for: indexPath) as! CollectionImageCell
        let image = fetchedResultsController.object(at: indexPath)
        cell.getImage(image: image)
       // dataController.saveContext(context: dataController.viewContext)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let image = fetchedResultsController.object(at: indexPath)
        dataController.viewContext.delete(image)
        dataController.saveContext(context: dataController.viewContext)
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath:
        IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
        
    }
}


