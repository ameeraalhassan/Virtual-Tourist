//
//  ViewController.swift
//  VirtualTourist
//
//  Created by Ameera AlHassan on 8/20/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import CoreData

class MapViewController: UIViewController, MKMapViewDelegate, UIGestureRecognizerDelegate {
    
    var pins: [MapViewPin]!
    
    var dataController: DataController!
    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpFetchedResultsController()
        setUpUI()
    }
    
    fileprivate func setUpUI() {
        mapView.delegate = self
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.mapLongPressed(_:)))
        mapView.addGestureRecognizer(longPressGesture)
    }
    
    @objc func mapLongPressed(_ sender: UILongPressGestureRecognizer){
        guard sender.state == UIGestureRecognizer.State.began else { return }
        
        let locationPoint = sender.location(in: mapView)
        let mapConrdinates = mapView.convert(locationPoint, toCoordinateFrom: mapView)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = mapConrdinates
        let newPin = MapViewPin(context: dataController.viewContext)
        newPin.latitude = annotation.coordinate.latitude
        newPin.longitude = annotation.coordinate.longitude
        pins.append(newPin)
        dataController.saveContext(context: dataController.viewContext)
        
        mapView.addAnnotation(annotation)
    }
    
    fileprivate func setUpFetchedResultsController() {
        let fetchRequest:NSFetchRequest<MapViewPin> = MapViewPin.fetchRequest()
        
        if let currentPins = try? dataController.viewContext.fetch(fetchRequest){
            pins = currentPins
        }
        for pin in pins {
            let annotation = MKPointAnnotation()
            annotation.coordinate.latitude = pin.latitude
            annotation.coordinate.longitude = pin.longitude
            mapView.addAnnotation(annotation)
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .detailDisclosure)
        }
        else {
            pinView!.annotation = annotation
        }
        return pinView
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let viewController = storyboard?.instantiateViewController(withIdentifier: "CollectionViewController") as! CollectionViewController
        
        for pin in pins {
            if pin.latitude == view.annotation?.coordinate.latitude && pin.longitude == view.annotation?.coordinate.longitude {
                viewController.pin = pin
                viewController.dataController = dataController
                mapView.deselectAnnotation(view.annotation, animated: true)
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
    }
    
}



