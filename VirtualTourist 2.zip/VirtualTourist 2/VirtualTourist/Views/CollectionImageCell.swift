//
//  CollectionImageCell.swift
//  VirtualTourist
//
//  Created by Ameera AlHassan on 8/20/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit
import Kingfisher
class CollectionImageCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    
    func getImage(image: CollectionView){
        if let imageData = image.imageData{
            imageView.image = UIImage(data: imageData)
        } else {
            let url = URL(string: image.imageURL!)
            imageView.kf.indicatorType = .activity
            imageView.kf.setImage(with: url)
            image.imageData = imageView.image?.pngData()
        }
    }
}
