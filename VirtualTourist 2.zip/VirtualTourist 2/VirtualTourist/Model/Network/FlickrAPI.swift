//
//  FlickrAPI.swift
//  VirtualTourist
//
//  Created by Ameera AlHassan on 8/20/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

class FlickrAPI {
    
    static let flickrObject = FlickrAPI()
    
    func fetchImagesForLocation(latitude: Double, longitude: Double, page: Int, completion: @escaping ([ImageDetails]?, Error? ) -> Void) {
        let request = URLRequest(url: URL(string: "https://api.flickr.com/services/rest/?api_key=6214228a033fdbd082c1cfafe1c29277&method=flickr.photos.search&format=json&lat=\(latitude)&lon=\(longitude)&per_page=10&page=\(page)&nojsoncallback=1")!)
        print(request)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let statusCode = (response as? HTTPURLResponse)?.statusCode {
                if statusCode >= 200 && statusCode < 300 {
                    
                    guard let data = data else { return }
                    
                    do {
                        
                        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                            let photos = json["photos"] as? [String: Any],
                            let photosArray = photos["photo"] as? [[String: Any]] {
                            
                            var flickrImages:[ImageDetails] = []
                            
                            for photo in photosArray {
                                let flickrImage = photo
                                if let id = flickrImage["id"] as? String,
                                    let secret = flickrImage["secret"] as? String,
                                    let server = flickrImage["server"] as? String,
                                    let farm = flickrImage["farm"] as? Int {
                                    flickrImages.append(ImageDetails(id: id, secret: secret, server: server, farm: farm ))
                                }
                            }
                            DispatchQueue.main.async {
                                completion(flickrImages, nil) }
                        }
                    }
                }
            }
        }
        task.resume()
    }
}

