//
//  ImageDetails.swift
//  VirtualTourist
//
//  Created by Ameera AlHassan on 8/20/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

struct ImageDetails: Codable {
    var id: String?
    var secret: String?
    var server: String?
    var farm: Int?
}

extension ImageDetails {
    
    init(id: String, secret: String, server: String, farm: Int){
        self.id = id
        self.secret = secret
        self.server = server
        self.farm = farm
    }
}
